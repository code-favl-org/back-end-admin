import { Body, Controller, Get, Post, Redirect, Render } from '@nestjs/common';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Roles } from '../../common/authorization';
import { Role } from '../../common/types/role';
import type { PortadaInicio } from './inicio.service';
import { InicioService } from './inicio.service';

/** Portada del sitio (/admin/web/inicio). Rol: Comunicación (y Admin). */
@ApiTags('Web · Portada')
@Controller('admin/web/inicio')
export class InicioController {
  constructor(private readonly inicio: InicioService) {}

  /** Muestra el formulario con el contenido actual de la portada. */
  @Roles(Role.editor)
  @Get()
  @Render('inicio/views/index')
  @ApiOperation({
    summary: 'Ver portada',
    description: 'HTML con los textos actuales. Rol: editor o admin.',
  })
  async ver() {
    return { inicio: await this.inicio.obtener() };
  }

  /** Guarda la portada y vuelve a mostrarla. */
  @Roles(Role.editor)
  @Post()
  @Redirect('/admin/web/inicio')
  @ApiOperation({
    summary: 'Guardar portada',
    description: 'Los campos que no se envíen se conservan tal como estaban.',
  })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        titulo: { type: 'string', example: 'Bienvenidos a FAVL' },
        subtitulo: { type: 'string', example: 'Federación Argentina de Vuelo Libre' },
        descripcion: { type: 'string', example: 'Somos la federación que agrupa a los clubes y pilotos.' },
      },
    },
  })
  @ApiResponse({ status: 302, description: 'Redirige otra vez a la portada.' })
  async guardar(@Body() dto: Partial<PortadaInicio>) {
    await this.inicio.guardar(dto);
  }
}
