import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Home } from './entity/home.entity';

/** Textos de la portada tal como los usan el formulario y la vista: `titulo`, `subtitulo`, `descripcion`. */
export interface PortadaInicio {
  titulo: string;
  subtitulo: string;
  descripcion: string;
}

/** Portada sin datos: la pantalla tiene que poder abrirse aunque la tabla todavía no tenga filas. */
const PORTADA_VACIA: PortadaInicio = { titulo: '', subtitulo: '', descripcion: '' };

/** Contenido de la portada del sitio: la única fila de `home`, editable desde `/admin/web/inicio`. */
@Injectable()
export class InicioService {
  constructor(@InjectRepository(Home) private readonly home: Repository<Home>) {}

  /**
   * Textos actuales de la portada.
   *
   * Sin filas devuelve los campos vacíos en lugar de fallar: la fila se crea la primera vez que
   * alguien guarda desde el formulario, y la pantalla tiene que abrirse igual.
   */
  async obtener(): Promise<PortadaInicio> {
    const fila = await this.filaActual();
    if (!fila) return { ...PORTADA_VACIA };

    return {
      titulo: fila.title ?? '',
      subtitulo: fila.subtitle ?? '',
      descripcion: fila.description ?? '',
    };
  }

  /**
   * Guarda los textos de la portada: actualiza la fila actual o la crea si todavía no hay ninguna.
   *
   * Solo se escriben los campos que vienen en el pedido: si llega incompleto (por ejemplo, probando
   * desde Swagger) el resto queda como estaba, sin borrar contenido.
   *
   * @param dto Campos del formulario; los que no vengan se conservan.
   */
  async guardar(dto: Partial<PortadaInicio>): Promise<void> {
    const fila = await this.filaActual();

    const datos = {
      title: dto.titulo ?? fila?.title ?? '',
      subtitle: dto.subtitulo ?? fila?.subtitle ?? '',
      description: dto.descripcion ?? fila?.description ?? '',
    };

    if (fila) await this.home.update(fila.id, datos);
    else await this.home.save(this.home.create(datos));
  }

  /**
   * Fila que se está editando: la última por `id` (la portada es una sola).
   *
   * Se usa `find` + `take` porque `findOne` de TypeORM exige condiciones (`where`) y acá no hay
   * ninguna con la que buscar: la tabla tiene una sola fila.
   */
  private async filaActual(): Promise<Home | null> {
    const [fila] = await this.home.find({ order: { id: 'DESC' }, take: 1 });
    return fila ?? null;
  }
}
