import { Body, Controller, Get, Param, Post, Redirect, Render } from '@nestjs/common';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../../common/decorators';
import { Roles } from '../../common/authorization';
import type { AuthUser } from '../../common/types';
import { Role } from '../../common/types/role';
import { NoticiasService } from './noticias.service';

/** Gestión de noticias del sitio (/admin/web/noticias). Rol: Comunicación (y Admin). */
@ApiTags('Web · Noticias')
@Controller('admin/web/noticias')
export class NoticiasController {
  constructor(private readonly noticias: NoticiasService) {}

  /** Listado de noticias (publicadas y borradores). */
  @Roles(Role.editor)
  @Get()
  @Render('noticias/views/listado')
  @ApiOperation({ summary: 'Listado de noticias', description: 'HTML con publicadas y borradores. Rol: editor o admin.' })
  async listado() {
    return { noticias: await this.noticias.listar() };
  }

  /** Formulario de alta; el autor se completa con el usuario logueado. */
  @Roles(Role.editor)
  @Get('nueva')
  @Render('noticias/views/nueva')
  @ApiOperation({
    summary: 'Formulario de nueva noticia',
    description: 'HTML con el formulario y las categorías. El autor se completa con el usuario logueado.',
  })
  nueva(@CurrentUser() user: AuthUser) {
    return {
      noticia: { estado: 'borrador', autor: user.nombre },
      categorias: this.noticias.categorias(),
      action: '/admin/web/noticias',
    };
  }

  /** Crea la noticia y vuelve al listado. */
  @Roles(Role.editor)
  @Post()
  @Redirect('/admin/web/noticias')
  @ApiOperation({
    summary: 'Crear noticia',
    description: 'Todavía no persiste nada (TODO en `NoticiasService`). El archivo de portada del formulario aún no se procesa.',
  })
  @ApiBody({
    schema: {
      type: 'object',
      required: ['titulo'],
      properties: {
        titulo: { type: 'string', example: 'Nuevo récord argentino en ala delta' },
        resumen: { type: 'string', example: 'El piloto cordobés voló 340 km sin motor.' },
        contenido: { type: 'string', description: 'HTML del cuerpo de la noticia.' },
        estado: { type: 'string', enum: ['Publicada', 'Borrador'], example: 'Borrador' },
        fecha: { type: 'string', format: 'date', example: '2026-03-02' },
        autor: { type: 'string', example: 'Admin' },
        categoria: { type: 'string', example: 'Competiciones' },
      },
    },
  })
  @ApiResponse({ status: 302, description: 'Redirige al listado.' })
  async crear(@Body() dto: Record<string, string>) {
    await this.noticias.crear(dto);
  }

  /** Formulario de edición de la noticia `id`. */
  @Roles(Role.editor)
  @Get(':id/editar')
  @Render('noticias/views/editar')
  @ApiOperation({ summary: 'Formulario de edición', description: 'HTML con el formulario de la noticia `id`.' })
  async editar(@Param('id') id: string) {
    return {
      noticia: await this.noticias.obtener(id),
      categorias: this.noticias.categorias(),
      action: `/admin/web/noticias/${id}`,
    };
  }

  /** Guarda los cambios de la noticia `id` y vuelve al listado. */
  @Roles(Role.editor)
  @Post(':id')
  @Redirect('/admin/web/noticias')
  @ApiOperation({
    summary: 'Guardar cambios de la noticia',
    description: 'Todavía no persiste nada (TODO en `NoticiasService`).',
  })
  @ApiBody({
    schema: {
      type: 'object',
      required: ['titulo'],
      properties: {
        titulo: { type: 'string', example: 'Nuevo récord argentino en ala delta' },
        resumen: { type: 'string', example: 'El piloto cordobés voló 340 km sin motor.' },
        contenido: { type: 'string', description: 'HTML del cuerpo de la noticia.' },
        estado: { type: 'string', enum: ['Publicada', 'Borrador'], example: 'Publicada' },
        fecha: { type: 'string', format: 'date', example: '2026-03-02' },
        autor: { type: 'string', example: 'Admin' },
        categoria: { type: 'string', example: 'Competiciones' },
      },
    },
  })
  @ApiResponse({ status: 302, description: 'Redirige al listado.' })
  async actualizar(@Param('id') id: string, @Body() dto: Record<string, string>) {
    await this.noticias.actualizar(id, dto);
  }
}
